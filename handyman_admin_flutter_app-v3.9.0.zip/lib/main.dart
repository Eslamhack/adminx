import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:handyman_admin_flutter/configs.dart';
import 'package:handyman_admin_flutter/locale/app_localizations.dart';
import 'package:handyman_admin_flutter/locale/base_language.dart';
import 'package:handyman_admin_flutter/model/material_you_model.dart';
import 'package:handyman_admin_flutter/screens/splashScreen/splash_screen.dart';
import 'package:handyman_admin_flutter/store/AppStore.dart';
import 'package:handyman_admin_flutter/store/app_configuration_store.dart';
import 'package:handyman_admin_flutter/utils/colors.dart';
import 'package:handyman_admin_flutter/utils/common.dart';
import 'package:handyman_admin_flutter/utils/constant.dart';
import 'package:handyman_admin_flutter/utils/firebase_messaging_utils.dart';
import 'package:nb_utils/nb_utils.dart';

import 'app_theme.dart';
import 'model/booking_status_response.dart';
import 'model/notification_list_response.dart';

//region Mobx Stores
AppStore appStore = AppStore();
AppConfigurationStore appConfigurationStore = AppConfigurationStore();
//endregion

//region App languages
late BaseLanguage locale;
//endregion

String currentPackageName = '';

List<BookingStatusResponse>? cachedBookingStatusDropdown;
List<NotificationData>? cachedNotifications;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (!isDesktop) {
    Firebase.initializeApp().then((value) {
      FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
    }).catchError((e) {
      log(e.toString());
      return e;
    });
  }
  passwordLengthGlobal = 6;
  appButtonBackgroundColorGlobal = primaryColor;
  defaultAppButtonTextColorGlobal = Colors.white;
  defaultRadius = 12;
  defaultBlurRadius = 0;
  defaultSpreadRadius = 0;
  defaultAppButtonElevation = 0;
  pageRouteTransitionDurationGlobal = 400.milliseconds;
  textBoldSizeGlobal = 14;
  textPrimarySizeGlobal = 14;
  textSecondarySizeGlobal = 12;
  textBoldSizeGlobal = 14;
  textPrimarySizeGlobal = 14;
  textSecondarySizeGlobal = 12;

  await initialize();

  localeLanguageList = languageList();

  Firebase.initializeApp().then((value) {
    /// Firebase Notification
    initFirebaseMessaging();
    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
  });

  await appStore.setLanguage(getStringAsync(SELECTED_LANGUAGE_CODE, defaultValue: DEFAULT_LANGUAGE));

  int val = getIntAsync(THEME_MODE_INDEX);

  if (val == THEME_MODE_LIGHT) {
    appStore.setDarkMode(false);
  } else if (val == THEME_MODE_DARK) {
    appStore.setDarkMode(true);
  }

  locale = await AppLocalizations().load(Locale(appStore.selectedLanguageCode));

  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
    init();
  }

  void init() async {
    //
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RestartAppWidget(
      child: Observer(
        builder: (_) => FutureBuilder<Color>(
          future: getMaterialYouData(),
          builder: (_, snap) {
            return Observer(
              builder: (_) => MaterialApp(
                debugShowCheckedModeBanner: false,
                navigatorKey: navigatorKey,
                home: SplashScreen(),
                title: APP_NAME,
                theme: AppTheme.lightTheme(color: snap.data),
                darkTheme: AppTheme.darkTheme(color: snap.data),
                themeMode: appStore.isDarkMode ? ThemeMode.dark : ThemeMode.light,
                supportedLocales: LanguageDataModel.languageLocales(),
                localizationsDelegates: [
                  AppLocalizations(),
                  GlobalMaterialLocalizations.delegate,
                  GlobalWidgetsLocalizations.delegate,
                  GlobalCupertinoLocalizations.delegate,
                ],
                localeResolutionCallback: (locale, supportedLocales) => locale,
                locale: Locale(appStore.selectedLanguageCode),
              ),
            );
          },
        ),
      ),
    );
  }
}
