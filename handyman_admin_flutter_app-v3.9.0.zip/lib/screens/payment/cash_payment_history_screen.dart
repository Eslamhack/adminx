import 'package:flutter/material.dart';
import 'package:handyman_admin_flutter/main.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../components/empty_error_state_widget.dart';
import '../../model/payment_history_model.dart';
import '../../networks/rest_apis.dart';
import '../../utils/constant.dart';
import 'component/payment_history_list_widget.dart';

class CashPaymentHistoryScreen extends StatefulWidget {
  final String bookingId;

  const CashPaymentHistoryScreen({Key? key, required this.bookingId}) : super(key: key);

  @override
  State<CashPaymentHistoryScreen> createState() => _CashPaymentHistoryScreenState();
}

class _CashPaymentHistoryScreenState extends State<CashPaymentHistoryScreen> {
  Future<List<PaymentHistoryData>>? future;

  @override
  void initState() {
    super.initState();
    init();
  }

  void init({bool flag = false}) async {
    future = getPaymentHistory(bookingId: widget.bookingId);
    if (flag) setState(() {});
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: future,
      builder: (context, snap) {
        if (snap.hasData) {
          if (snap.data.validate().isEmpty) return Offstage();
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(locale.paymentHistory, style: boldTextStyle(size: LABEL_TEXT_SIZE)),
                8.height,
                Container(
                  decoration: boxDecorationWithRoundedCorners(borderRadius: radius(defaultRadius), backgroundColor: context.cardColor),
                  padding: EdgeInsets.all(16),
                  child: AnimatedScrollView(
                    listAnimationType: ListAnimationType.FadeIn,
                    fadeInConfiguration: FadeInConfiguration(duration: 2.seconds),
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      8.height,
                      if (snap.data.validate().isNotEmpty)
                        AnimatedListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: snap.data.validate().length,
                          listAnimationType: ListAnimationType.FadeIn,
                          fadeInConfiguration: FadeInConfiguration(duration: 2.seconds),
                          itemBuilder: (_, i) {
                            return PaymentHistoryListWidget(
                              data: snap.data.validate()[i],
                              index: i,
                              length: snap.data.validate().length.validate(),
                            );
                          },
                        ),
                      if (snap.data.validate().isEmpty) Text(locale.noDataFound),
                    ],
                  ),
                ),
              ],
            ),
          );
        }
        return snapWidgetHelper(
          snap,
          errorBuilder: (p0) {
            return NoDataWidget(
              title: locale.retryPaymentDetails,
              imageWidget: ErrorStateWidget(),
              onRetry: () {
                init(flag: true);
              },
            );
          },
        );
      },
    );
  }
}
