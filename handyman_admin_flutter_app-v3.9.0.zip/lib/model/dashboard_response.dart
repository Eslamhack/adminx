import 'package:handyman_admin_flutter/model/post_job_data.dart';
import 'package:handyman_admin_flutter/model/user_data.dart';

import 'booking_data_model.dart';

class DashboardResponse {
  bool? status;
  num? totalBooking;
  num? totalService;
  num? totalProvider;
  num? totalTax;
  num? myEarning;
  var totalRevenue;
  List<num>? monthlyRevenue;
  List<UserData>? provider;
  List<UserData>? user;
  List<BookingData>? upcomingBooking;
  num? notificationUnreadCount;
  List<PostJobData>? myPostJobData;

  DashboardResponse({
    this.status,
    this.totalBooking,
    this.totalService,
    this.totalProvider,
    this.totalRevenue,
    this.totalTax,
    this.myEarning,
    this.monthlyRevenue,
    this.provider,
    this.user,
    this.upcomingBooking,
    this.notificationUnreadCount,
    this.myPostJobData,
  });

  DashboardResponse.fromJson(dynamic json) {
    status = json['status'];
    totalBooking = json['total_booking'];
    totalService = json['total_service'];
    totalProvider = json['total_provider'];
    totalRevenue = json['total_revenue'] ?? 0;
    totalTax = json['total_tax'];
    myEarning = json['my_earning'] ?? 0;
    monthlyRevenue = json['monthly_revenue'] != null ? json['monthly_revenue'].cast<int>() : [];
    if (json['provider'] != null) {
      provider = [];
      json['provider'].forEach((v) {
        provider?.add(UserData.fromJson(v));
      });
    }
    if (json['user'] != null) {
      user = [];
      json['user'].forEach((v) {
        user?.add(UserData.fromJson(v));
      });
    }
    if (json['upcomming_booking'] != null) {
      upcomingBooking = [];
      json['upcomming_booking'].forEach((v) {
        upcomingBooking?.add(BookingData.fromJson(v));
      });
    }
    notificationUnreadCount = json['notification_unread_count'];
    myPostJobData = json['post_requests'] != null ? (json['post_requests'] as List).map((i) => PostJobData.fromJson(i)).toList() : null;
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['total_booking'] = totalBooking;
    map['total_service'] = totalService;
    map['total_provider'] = totalProvider;
    map['total_revenue'] = totalRevenue;
    map['monthly_revenue'] = monthlyRevenue;
    map['total_tax'] = totalTax;
    map['my_earning'] = myEarning;
    if (provider != null) {
      map['provider'] = provider?.map((v) => v.toJson()).toList();
    }
    if (user != null) {
      map['user'] = user?.map((v) => v.toJson()).toList();
    }
    if (upcomingBooking != null) {
      map['upcomming_booking'] = upcomingBooking?.map((v) => v.toJson()).toList();
    }
    map['notification_unread_count'] = notificationUnreadCount;
    if (this.myPostJobData != null) {
      map['post_requests'] = this.myPostJobData!.map((v) => v.toJson()).toList();
    }

    return map;
  }
}
