class EarningModel {
  int? providerId;
  String? providerName;
  num? commission;
  String? commissionType;
  num? totalBookings;
  num? totalEarning;
  num? taxes;
  num? adminEarning;
  num? providerPaidEarningFormate;
  String? providerImage;
  String? email;
  String? taxesFormate;
  num? providerDueAmount;
  num? providerPaidEarning;
  num? handymanTotalAmount;

  EarningModel({
    this.adminEarning,
    this.commission,
    this.commissionType,
    this.providerPaidEarningFormate,
    this.providerId,
    this.providerName,
    this.taxes,
    this.totalBookings,
    this.totalEarning,
    this.providerImage,
    this.email,
    this.taxesFormate,
    this.providerDueAmount,
    this.providerPaidEarning,
    this.handymanTotalAmount,
  });

  factory EarningModel.fromJson(Map<String, dynamic> json) {
    return EarningModel(
      commission: json['commission'],
      providerPaidEarningFormate: json['provider_paid_earning_formate'],
      providerId: json['provider_id'],
      commissionType: json['commission_type'],
      providerName: json['provider_name'],
      taxes: json['taxes'],
      adminEarning: json['admin_earning'],
      totalBookings: json['total_bookings'],
      totalEarning: json['total_earning'],
      providerImage: json['provider_image'],
      email: json['email'],
      taxesFormate: json['taxes_formate'],
      providerDueAmount: json['provider_due_amount'],
      providerPaidEarning: json['provider_paid_earning'],
      handymanTotalAmount: json['handyman_total_amount'],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['admin_earning'] = this.adminEarning;
    data['commission'] = this.commission;
    data['provider_paid_earning_formate'] = this.providerPaidEarningFormate;
    data['commission_type'] = this.commissionType;
    data['provider_id'] = this.providerId;
    data['provider_name'] = this.providerName;
    data['taxes'] = this.taxes;
    data['total_bookings'] = this.totalBookings;
    data['total_earning'] = this.totalEarning;
    data['provider_image'] = this.providerImage;
    data['email'] = this.email;
    data['taxes_formate'] = this.taxesFormate;
    data['provider_due_amount'] = this.providerDueAmount;
    data['provider_paid_earning'] = this.providerPaidEarning;
    data['handyman_total_amount'] = this.handymanTotalAmount;
    return data;
  }
}
