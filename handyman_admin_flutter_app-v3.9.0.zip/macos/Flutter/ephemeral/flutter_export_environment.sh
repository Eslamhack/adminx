#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/iqonicdesign/flutter_sdks/flutter_3_24_2"
export "FLUTTER_APPLICATION_PATH=/Users/iqonicdesign/Documents/dev/live/handyman_admin_flutter_app"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=3.8.0"
export "FLUTTER_BUILD_NUMBER=3.8.0"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
